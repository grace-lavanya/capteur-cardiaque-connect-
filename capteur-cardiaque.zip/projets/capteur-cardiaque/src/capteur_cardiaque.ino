/*
 * Capteur cardiaque connecté
 * Auteur : Grâce Destinée LEBIKI LAVANYA
 * Description : Mesure de la fréquence cardiaque en temps réel
 *               Affichage sur LCD 16x2 + envoi des données via Bluetooth HC-05
 */

#include <LiquidCrystal.h>
#include <SoftwareSerial.h>

// ===== LCD (RS, EN, D4, D5, D6, D7) =====
LiquidCrystal lcd(7, 8, 9, 10, 11, 12);

// ===== BLUETOOTH HC-05 =====
SoftwareSerial bluetooth(2, 3); // RX, TX

// ===== CAPTEUR KY-039 =====
#define PIN_CAPTEUR     A0
#define SEUIL_BATTEMENT 600   // Seuil de détection du pic de pulsation

// ===== VARIABLES =====
int valeur            = 0;
int valeurPrecedente  = 0;
bool battementDetecte = false;
unsigned long dernierBattement = 0;
unsigned long intervalBattement = 0;
int bpm               = 0;
int compteur          = 0;
unsigned long dernierAffichage = 0;

void setup() {
  lcd.begin(16, 2);
  bluetooth.begin(9600);
  Serial.begin(9600);

  lcd.setCursor(0, 0);
  lcd.print("Capteur cardiaque");
  lcd.setCursor(0, 1);
  lcd.print("Initialisation...");
  delay(2000);
  lcd.clear();
}

void loop() {
  valeur = analogRead(PIN_CAPTEUR);

  // Détection d'un pic (battement)
  if (valeur > SEUIL_BATTEMENT && !battementDetecte) {
    battementDetecte = true;
    unsigned long maintenant = millis();

    if (dernierBattement > 0) {
      intervalBattement = maintenant - dernierBattement;
      // Calcul BPM : 60000ms / intervalle entre 2 battements
      if (intervalBattement > 300 && intervalBattement < 2000) {
        bpm = 60000 / intervalBattement;
      }
    }
    dernierBattement = maintenant;
  }

  // Réinitialisation quand le signal redescend
  if (valeur < SEUIL_BATTEMENT - 50) {
    battementDetecte = false;
  }

  // Affichage toutes les secondes
  if (millis() - dernierAffichage >= 1000) {
    dernierAffichage = millis();
    afficherLCD();
    envoyerBluetooth();
  }

  delay(10);
}

void afficherLCD() {
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Freq. cardiaque:");
  lcd.setCursor(0, 1);

  if (bpm > 0) {
    lcd.print(bpm);
    lcd.print(" BPM");

    // Indication état
    if (bpm < 60) lcd.print(" LENT");
    else if (bpm > 100) lcd.print(" ELEVE");
    else lcd.print(" NORMAL");
  } else {
    lcd.print("Mesure en cours..");
  }
}

void envoyerBluetooth() {
  if (bpm > 0) {
    bluetooth.print("BPM:");
    bluetooth.println(bpm);
    Serial.print("BPM: ");
    Serial.println(bpm);
  }
}
