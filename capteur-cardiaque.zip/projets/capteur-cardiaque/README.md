# ❤️ Capteur cardiaque connecté

Système de mesure de la fréquence cardiaque en temps réel avec affichage LCD et transmission des données via Bluetooth.

## 🎯 Fonctionnalités

- Mesure de la fréquence cardiaque en temps réel (BPM)
- Affichage sur écran LCD 16x2 avec indication d'état (Normal / Lent / Élevé)
- Transmission des données via module Bluetooth HC-05
- Détection de pics de pulsation par seuillage du signal

## 🛠️ Matériel

| Composant | Référence |
|-----------|-----------|
| Microcontrôleur | Arduino Uno |
| Capteur de pulsation | KY-039 |
| Écran | LCD 16x2 |
| Bluetooth | HC-05 |

## ⚙️ Branchements

| Composant | Pin Arduino |
|-----------|-------------|
| Capteur KY-039 | A0 |
| LCD RS | 7 |
| LCD EN | 8 |
| LCD D4-D7 | 9, 10, 11, 12 |
| HC-05 RX | 2 |
| HC-05 TX | 3 |

## 🚀 Lancer le projet

1. Installer la librairie `LiquidCrystal` dans l'Arduino IDE
2. Ouvrir `src/capteur_cardiaque.ino`
3. Téléverser sur Arduino Uno
4. Placer le doigt sur le capteur KY-039

## 📊 Résultats

- Mesure en temps réel avec rafraîchissement toutes les secondes
- Plage de mesure : 30 – 200 BPM
- Données transmises en Bluetooth au format `BPM:XX`
